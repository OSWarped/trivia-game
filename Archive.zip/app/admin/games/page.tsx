'use client';

export default function ManageGames() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Manage Games</h1>
      <p>Functionality to view and edit game settings goes here.</p>
    </div>
  );
}
