'use client';

export default function ManageTeams() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Manage Teams</h1>
      <p>Functionality to assign players and manage team details goes here.</p>
    </div>
  );
}
