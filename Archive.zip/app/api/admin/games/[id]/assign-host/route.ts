import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const { id } = params;

  try {
    const { hostId } = await req.json(); // Expecting hostId to be sent in the request

    if (!hostId) {
      return NextResponse.json({ error: 'Host ID is required' }, { status: 400 });
    }

    // Ensure the game exists
    const game = await prisma.game.findUnique({
      where: { id },
    });

    if (!game) {
      return NextResponse.json({ error: 'Game not found' }, { status: 404 });
    }

    // First, delete all existing host assignments for the game
    await prisma.hostGame.deleteMany({
      where: {
        gameId: id, // Delete any existing host assignments for this game
      },
    });

    // Now, let's create the new host assignment
    const updatedHostGame = await prisma.hostGame.create({
      data: {
        hostId: hostId,
        gameId: id, // Directly use gameId instead of 'game' relation
      },
    });

    return NextResponse.json(updatedHostGame);
  } catch (error) {
    console.error('Error assigning host:', error);
    return NextResponse.json({ error: 'Failed to assign host' }, { status: 500 });
  }
}
