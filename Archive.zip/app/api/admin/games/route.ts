import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(req: Request) {
  try {
    // Fetch all games with associated host, hostingSite, and teams
    const games = await prisma.game.findMany({
      include: {
        hostingSite: true,  // Include hosting site details
        hostGames: {
          include: {
            host: true, // Include host details for the game
          },
        },
        teams: true,       // Include associated teams
        rounds: {
          include: {
            questions: true, // Include associated questions
          },
        },
      },
    });

    if (!games || games.length === 0) {
      return NextResponse.json({ error: 'No games found' }, { status: 404 });
    }

    return NextResponse.json(games);
  } catch (error) {
    console.error('Error fetching games:', error);
    return NextResponse.json({ error: 'Failed to fetch games' }, { status: 500 });
  }
}
