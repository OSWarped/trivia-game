import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function DELETE(
    req: Request,
    { params }: { params: Promise<{ id: string }> }
  ) {
    try {
      // Await params to handle the promise
      const { id } = await params;
  
      // Validate the ID
      if (!id) {
        console.error('Invalid or missing site ID.');
        return NextResponse.json({ error: 'Invalid site ID' }, { status: 400 });
      }
  
      console.log(`Deleting site with ID: ${id}`);
  
      // Check if the site exists
      const site = await prisma.hostingSite.findUnique({
        where: { id },
      });
  
      if (!site) {
        console.error(`Site with ID ${id} not found.`);
        return NextResponse.json({ error: 'Site not found' }, { status: 404 });
      }
  
      // Proceed with the deletion
      await prisma.hostingSite.delete({
        where: { id },
      });
  
      console.log(`Site with ID ${id} deleted successfully.`);
      return NextResponse.json({ message: 'Site deleted successfully' }, { status: 200 });
  
    } catch (error) {
      console.error('Error deleting site:', error);
  
      // Specific handling for Prisma-related errors
      if (error instanceof TypeError && error.message.includes('payload')) {
        console.error('Payload type issue detected.');
        return NextResponse.json({ error: 'Internal server error: invalid payload' }, { status: 500 });
      }
  
      return NextResponse.json({ error: 'Failed to delete site' }, { status: 500 });
    }
  }
  
export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
    const { id } = await params;
    const { name, location } = await req.json();
  
    try {
      const updatedSite = await prisma.hostingSite.update({
        where: { id },
        data: { name, location },
      });
      return NextResponse.json(updatedSite);
    } catch (error) {
      console.error(error);
      return NextResponse.json({ error: 'Failed to update site' }, { status: 500 });
    }
  }
  