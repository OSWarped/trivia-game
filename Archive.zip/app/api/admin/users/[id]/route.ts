import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  try {
    const { name, email, roles } = await req.json();

    // Validate input
    if (!name || !email || !roles) {
      return NextResponse.json({ error: 'Invalid input data' }, { status: 400 });
    }

    // Prepare roles data for update
    const rolesData = roles.map((role: string) => {
      if (role === 'HOST') {
        // For 'HOST' role, do not connect to any HostingSite
        return { role }; // Only assign the role, no need to connect to a HostingSite
      } else {
        // For other roles, associate with a HostingSite
        return {
          role,
          hostingSite: {
            connect: { id: 'your-default-hosting-site-id' }, // Adjust this part if needed
          },
        };
      }
    });

    // Update user details and roles
    const updatedUser = await prisma.user.update({
      where: { id },
      data: {
        name,
        email,
        siteRoles: {
          deleteMany: {}, // Remove existing roles
          create: rolesData, // Create new roles
        },
      },
    });

    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error('Error updating user:', error instanceof Error ? error.message : error);
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 });
  }
}
