import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  try {
    const users = await prisma.user.findMany({
      include: {
        siteRoles: true, // Include roles in the response if needed
      },
    });

    const formattedUsers = users.map((user) => ({
      id: user.id,
      email: user.email,
      name: user.name,
      roles: user.siteRoles.map((role) => role.role),
    }));

    return NextResponse.json(formattedUsers);
  } catch (error) {
    // Safeguard against null or undefined errors
    console.error('Error fetching users:', error instanceof Error ? error.message : error);
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
  }
}
