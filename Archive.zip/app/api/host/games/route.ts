import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import jwt from 'jsonwebtoken';

const prisma = new PrismaClient();

interface DecodedToken {
  id: string;
  email: string;
  roles: string[];
}

export async function GET(req: Request) {
  const user = await getUserFromRequest(req);

  // Debugging: Log user info
  console.log('Decoded user:', user);

  if (!user || !user.roles.includes('HOST')) {
    console.error('Unauthorized access - no host role');
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  try {
    // Force test query with known hostId
    const hostId = user.id; // The id of the current host
    console.log('Host ID:', hostId); // Log the hostId for debugging

    // Fetch games for the host
    const games = await prisma.game.findMany({
      where: {
        hostGames: {
          some: {
            hostId: hostId, // Match the hostId from the user
          },
        },
      },
      include: {
        hostingSite: true,
        hostGames: {
          include: {
            host: true,
          },
        },
      },
    });

    // Debugging: Log the fetched games
    console.log('Fetched games:', games);

    return NextResponse.json(games);
  } catch (error) {
    console.error('Error fetching host games:', error);
    return NextResponse.json({ error: 'Failed to fetch host games' }, { status: 500 });
  }
}

// Helper function to get user from request
async function getUserFromRequest(req: Request) {
  const token =
    req.headers.get('Authorization')?.split(' ')[1] ||
    req.headers.get('cookie')?.split('; ').find((cookie) => cookie.startsWith('token='))?.split('=')[1];

  console.log('Received token before decoding:', token); // Log the token before decoding

  if (!token) return null;

  try {
    const decoded = await decodeJWT(token); // Decode the JWT to get user info
    console.log('Decoded token:', decoded); // Log the decoded token for debugging
    return decoded; // Return the decoded token directly
  } catch (err) {
    console.error('Failed to decode token:', err);
    return null;
  }
}

async function decodeJWT(token: string): Promise<DecodedToken> {
  try {
    const secretKey = process.env.JWT_SECRET || 'your-secret-key'; // Ensure this matches the key used when signing the JWT
    console.log('Using secret key:', secretKey); // Log the secret key (do not log the actual secret in production)

    const decoded = jwt.verify(token, secretKey) as DecodedToken;
    console.log('Decoded JWT:', decoded); // Log the decoded token
    return decoded;
  } catch (error) {
    console.error('Failed to decode JWT:', error);
    throw new Error('Invalid or expired token');
  }
}
