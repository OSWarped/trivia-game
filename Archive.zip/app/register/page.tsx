"use client";

import { useSearchParams, useRouter } from 'next/navigation';
//import RootLayout from '..//layout'; // Adjust the import path as necessary

export default function RegisterPage() {
  const searchParams = useSearchParams();
  const router = useRouter();

  async function handleRegister(event: React.FormEvent) {
    event.preventDefault();

    // Call registration API
    const res = await fetch('/api/auth/register', { method: 'POST', /* user info */ });
    if (res.ok) {
      router.push(`/join?siteId=${searchParams.get('siteId')}&gameId=${searchParams.get('gameId')}`);
    } else {
      alert('Registration failed');
    }
  }

  return (
    <form onSubmit={handleRegister}>
      <h1>Register</h1>
      <label>
        Email:
        <input type="email" name="email" required />
      </label>
      <label>
        Password:
        <input type="password" name="password" required />
      </label>
      <button type="submit">Register</button>
    </form>
  );
}
