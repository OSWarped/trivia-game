-- AlterTable
ALTER TABLE "SiteRole" ALTER COLUMN "siteId" DROP NOT NULL;
