-- AlterTable
ALTER TABLE "Round" ADD COLUMN     "pointPool" INTEGER[];
