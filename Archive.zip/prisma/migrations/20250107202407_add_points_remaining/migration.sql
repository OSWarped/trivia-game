-- AlterTable
ALTER TABLE "Team" ADD COLUMN     "remainingPoints" INTEGER[];
