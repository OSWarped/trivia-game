-- AlterTable
ALTER TABLE "GameState" ADD COLUMN     "scoresVisibleToPlayers" BOOLEAN NOT NULL DEFAULT false;
