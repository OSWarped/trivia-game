-- AlterTable
ALTER TABLE "TeamMembership" ALTER COLUMN "gameId" DROP NOT NULL;
