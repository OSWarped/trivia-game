-- AlterTable
ALTER TABLE "GameState" ADD COLUMN     "pointPool" INTEGER[],
ADD COLUMN     "pointsRemaining" JSONB;
