-- AlterTable
ALTER TABLE "Question" ADD COLUMN     "sortOrder" INTEGER NOT NULL DEFAULT 0;
