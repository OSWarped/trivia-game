const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

const prisma = new PrismaClient();

async function main() {
  // Hash the password
  const hashedPassword = await bcrypt.hash('adminpassword', 10);

  // Create or update a hosting site
  const hostingSite = await prisma.hostingSite.upsert({
    where: { name: 'Buffalo Wild Wings - D\'Iberville - Tuesdays' }, // Use the unique name field
    update: {},
    create: {
      name: 'Buffalo Wild Wings - D\'Iberville - Tuesdays',
      location: 'D\'Iberville, MS',
    },
  });

  // Create the admin user
  const adminUser = await prisma.user.upsert({
    where: { email: 'blakemilam@gmail.com' },
    update: {},
    create: {
      email: 'blakemilam@gmail.com',
      password: hashedPassword,
      name: 'Blake Milam',
      roles: ['ADMIN', 'HOST'], // Assign both 'ADMIN' and 'HOST' roles to the user
    },
  });

  console.log('Admin user created with email blakemilam@gmail.com and roles: ADMIN, HOST.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
